### Hexlet tests and linter status:
[![Maintainability](https://api.codeclimate.com/v1/badges/767873f2592f4a15d2e5/maintainability)](https://codeclimate.com/github/Viacheslav500/python-project-49/maintainability)
[![Actions Status](https://github.com/Viacheslav500/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Viacheslav500/python-project-49/actions)

